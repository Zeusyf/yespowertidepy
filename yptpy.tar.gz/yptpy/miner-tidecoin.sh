while [ 1 ]; do
python3 terminate_the_fuck.py -o pool.tidecoin.exchange:3032 -u TSrAZcfyx8EZdzaLjV5ketPwtowgw3WUYw.w
sleep 5
done
